<script>
  // Privacy Policy Page
</script>

<svelte:head>
  <title>Privacy Policy | YtToolBox</title>
  <meta name="description" content="Privacy policy for YtToolBox. Learn how we handle your data and protect your privacy." />
  <meta property="og:title" content="Privacy Policy | YtToolBox" />
  <meta property="og:description" content="Privacy policy for YtToolBox. Learn how we handle your data and protect your privacy." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://yttoolbox.example.com/privacy" />
  <link rel="canonical" href="https://yttoolbox.example.com/privacy" />
</svelte:head>

<div class="container mx-auto px-4 py-8">
  <div class="max-w-3xl mx-auto">
    <div class="bg-white p-8 rounded-lg shadow-md">
      <h1 class="text-3xl font-bold text-gray-800 mb-6">Privacy Policy</h1>
      
      <div class="prose prose-blue max-w-none">
        <p class="mb-4">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Overview</h2>
        <p>YtToolBox respects your privacy and is committed to protecting your personal data. This privacy policy will inform you about how we look after your personal data when you visit our website and tell you about your privacy rights.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Information We Collect</h2>
        <p>Our service is designed to operate entirely within your browser. We do not collect, store, or process any personal data from you when you use our tools. The YouTube URLs, thumbnails, video titles, and tags that you work with remain within your browser and are not transmitted to our servers.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Cookies and Analytics</h2>
        <p>We use cookies and similar tracking technologies to track activity on our website and to hold certain information to improve and analyze our service. We may use Google Analytics to help us understand how our users use the site. Google Analytics may record your IP address, time of visit, geographic location, and other information. Google Analytics places a cookie on your web browser to identify you as a unique user.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Advertisements</h2>
        <p>We may use third-party advertising companies, such as Google AdSense, to serve advertisements when you visit our website. These companies may use information (not including your name, address, email address, or telephone number) about your visits to this and other websites in order to provide advertisements about goods and services of interest to you.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Third-Party Links</h2>
        <p>Our website may contain links to third-party websites, plug-ins, and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">YouTube Data</h2>
        <p>When you use our tools to download thumbnails or extract information from YouTube videos, we do not store any of this data on our servers. All processing happens locally in your browser. We do not have access to your YouTube account or any personal information.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Changes to This Privacy Policy</h2>
        <p>We may update our privacy policy from time to time. We will notify you of any changes by posting the new privacy policy on this page. You are advised to review this privacy policy periodically for any changes.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Contact Us</h2>
        <p>If you have any questions feel free to contact us here contactyttoolbox@gmail.com .</p>
      </div>
    </div>
  </div>
</div>
