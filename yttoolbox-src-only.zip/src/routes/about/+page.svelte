<script>
  // About Page
</script>

<svelte:head>
  <title>About YtToolBox | Free Online YouTube Tools</title>
  <meta name="description" content="Learn about YtToolBox - a collection of free online tools for YouTube content creators and viewers to extract thumbnails, titles, and generate tags." />
  <meta property="og:title" content="About YtToolBox | Free Online YouTube Tools" />
  <meta property="og:description" content="Learn about YtToolBox - a collection of free online tools for YouTube content creators and viewers to extract thumbnails, titles, and generate tags." />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="https://yttoolbox.example.com/about" />
  <link rel="canonical" href="https://yttoolbox.example.com/about" />
</svelte:head>

<div class="container mx-auto px-4 py-8">
  <div class="max-w-3xl mx-auto">
    <div class="bg-white p-8 rounded-lg shadow-md">
      <h1 class="text-3xl font-bold text-gray-800 mb-6">About YtToolBox</h1>
      
      <div class="prose prose-blue max-w-none">
        <p class="mb-4">Welcome to YtToolBox, a collection of free online tools designed to help YouTube content creators and viewers.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Our Mission</h2>
        <p>Our mission is to provide simple, fast, and free tools that make working with YouTube content easier. We believe in creating utility tools that respect your privacy and work efficiently without unnecessary complexity.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Our Tools</h2>
        
        <h3 class="text-lg font-medium mt-4 mb-2">YouTube Thumbnail Downloader</h3>
        <p>Our thumbnail downloader lets you easily extract high-quality thumbnails from any YouTube video. Simply paste the video URL and download thumbnails in various resolutions. This is perfect for content creators who want to analyze competitors' thumbnails or for viewers who want to save eye-catching thumbnails.</p>
        
        <h3 class="text-lg font-medium mt-4 mb-2">YouTube Title Extractor</h3>
        <p>Need to reference a YouTube video title? Our title extractor makes it easy to copy the exact title of any YouTube video with just a click. This tool is especially useful for content creators doing research or viewers wanting to share video titles.</p>
        
        <h3 class="text-lg font-medium mt-4 mb-2">YouTube Tags Generator</h3>
        <p>Optimize your YouTube videos with our tags generator. This tool helps you create relevant tags based on video titles, improving the discoverability of your content. Better tags can help your videos reach more viewers and appear in more search results.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">How It Works</h2>
        <p>All our tools work directly in your browser - no need to install anything. We use public YouTube APIs and metadata to extract information, all while respecting YouTube's terms of service. Your data never leaves your browser, ensuring your privacy.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">About The Developer</h2>
        <p>YtToolBox was created by a small team of web developers who are passionate about creating useful tools for the YouTube community. We developed this toolbox because we found ourselves frequently needing these features while working with YouTube content.</p>
        
        <h2 class="text-xl font-semibold mt-6 mb-3">Contact Us</h2>
        <p>Have suggestions for improvements or new tools? We'd love to hear from you! Contact us at feedback@yttoolbox.example.com.</p>
      </div>
    </div>
  </div>
</div>
